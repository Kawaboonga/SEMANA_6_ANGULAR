// src/app/core/services/course.service.ts

import { Injectable } from '@angular/core';
import { Course } from '@core/models/course.model';
import { CarouselItem } from '@shared/components/carousel/carousel.types';

@Injectable({
  providedIn: 'root',
})
export class CourseService {
  // ============================================================
  // 1) DATA LOCAL DE CURSOS (mock)
  // ============================================================
  // Por ahora todos los cursos viven acá en memoria.
  // Más adelante esto se puede mover a un JSON externo o a una API real.
  private courses: Course[] = [
    {
      id: 'curso-guitarra-rock',
      slug: 'curso-intensivo-guitarra-rock',
      title: 'Curso intensivo de guitarra rock',
      tutorId: 'marco-vidal',
      tutorName: 'Marco Vidal',

      difficulty: 'Intermedio',
      level: 'Intermedio',

      duration: '16 h · 8 clases',
      durationHours: 16,
      totalLessons: 8,
      lessonsCount: 8,

      shortDescription: 'Domina riffs, power chords y solos básicos de rock.',
      description:
        'En este curso trabajarás repertorio real de rock, técnica de púa, palm mute, power chords y construcción de solos sencillos sobre backing tracks.',
      imageUrl: '/assets/img/course/curso-guitarra-e2.jpg',

      rating: 4.8,
      ratingCount: 32,

      modalities: ['Presencial', 'Online'],

      stages: [
        'Fundamentos de palm mute',
        'Riffs clásicos',
        'Power chords y progresiones',
        'Introducción a solos',
      ],
      learnOutcomes: [
        'Tocar riffs con buen timing.',
        'Entender progresiones de rock.',
        'Improvisar solos sencillos.',
      ],

      reviews: [
        {
          author: 'Estudiante 1',
          rating: 5,
          comment: 'Curso muy práctico, lleno de ejemplos reales.',
          createdAt: '2024-05-10',
        },
      ],

      showInCarousel: true,
      isFeatured: true,
      isOffer: false,
      isNew: true,
      isActive: true,

      priceCLP: 89990,
      price: 89990,
      priceLabel: '$89.990',
    },

    {
      id: 'curso-guitarra-acustica',
      slug: 'curso-guitarra-rock',
      title: 'Curso de guitarra',
      tutorId: 'marco-vidal',
      tutorName: 'Marco Vidal',

      difficulty: 'Intermedio',
      level: 'Intermedio',

      duration: '16 h · 8 clases',
      durationHours: 16,
      totalLessons: 8,
      lessonsCount: 8,

      shortDescription: 'Domina riffs, power chords y solos básicos de rock.',
      description:
        'En este curso trabajarás repertorio real de rock, técnica de púa, palm mute, power chords y construcción de solos sencillos sobre backing tracks.',
      imageUrl: '/assets/img/course/curso-guitarra-e.jpg',

      rating: 4.8,
      ratingCount: 32,

      modalities: ['Presencial', 'Online'],

      stages: [
        'Fundamentos de palm mute',
        'Riffs clásicos',
        'Power chords y progresiones',
        'Introducción a solos',
      ],
      learnOutcomes: [
        'Tocar riffs con buen timing.',
        'Entender progresiones de rock.',
        'Improvisar solos sencillos.',
      ],

      reviews: [
        {
          author: 'Estudiante 1',
          rating: 5,
          comment: 'Curso muy práctico, lleno de ejemplos reales.',
          createdAt: '2024-05-10',
        },
      ],

      showInCarousel: true,
      isFeatured: true,
      isOffer: false,
      isNew: true,
      isActive: true,

      priceCLP: 89990,
      price: 89990,
      priceLabel: '$89.990',
    },

    {
      id: 'curso-bajo',
      slug: 'curso-bajo-rock',
      title: 'Curso de bajo',
      tutorId: 'tomas-lagos',
      tutorName: 'Tomás Lagos',

      difficulty: 'Intermedio',
      level: 'Intermedio',

      duration: '16 h · 8 clases',
      durationHours: 16,
      totalLessons: 8,
      lessonsCount: 8,

      shortDescription: 'Domina riffs, power chords y solos básicos de rock.',
      description:
        'En este curso trabajarás repertorio real de rock, técnica de púa, palm mute, power chords y construcción de solos sencillos sobre backing tracks.',
      imageUrl: '/assets/img/course/curso-bajo.jpg',

      rating: 4.8,
      ratingCount: 32,

      modalities: ['Presencial', 'Online'],

      stages: [
        'Fundamentos de palm mute',
        'Riffs clásicos',
        'Power chords y progresiones',
        'Introducción a solos',
      ],
      learnOutcomes: [
        'Tocar riffs con buen timing.',
        'Entender progresiones de rock.',
        'Improvisar solos sencillos.',
      ],

      reviews: [
        {
          author: 'Estudiante 1',
          rating: 5,
          comment: 'Curso muy práctico, lleno de ejemplos reales.',
          createdAt: '2024-05-10',
        },
      ],

      showInCarousel: true,
      isFeatured: true,
      isOffer: false,
      isNew: true,
      isActive: true,

      priceCLP: 89990,
      price: 89990,
      priceLabel: '$89.990',
    },

    {
      id: 'curso-bateria',
      slug: 'curso-bateria-rock',
      title: 'Curso de bateria',
      tutorId: 'esteban-rojas',
      tutorName: 'Esteban Rojas',

      difficulty: 'Intermedio',
      level: 'Intermedio',

      duration: '16 h · 8 clases',
      durationHours: 16,
      totalLessons: 8,
      lessonsCount: 8,

      shortDescription: 'Domina riffs, power chords y solos básicos de rock.',
      description:
        'En este curso trabajarás repertorio real de rock, técnica de púa, palm mute, power chords y construcción de solos sencillos sobre backing tracks.',
      imageUrl: '/assets/img/course/curso-bateria.jpg',

      rating: 4.8,
      ratingCount: 32,

      modalities: ['Presencial', 'Online'],

      stages: [
        'Fundamentos de palm mute',
        'Riffs clásicos',
        'Power chords y progresiones',
        'Introducción a solos',
      ],
      learnOutcomes: [
        'Tocar riffs con buen timing.',
        'Entender progresiones de rock.',
        'Improvisar solos sencillos.',
      ],

      reviews: [
        {
          author: 'Estudiante 1',
          rating: 5,
          comment: 'Curso muy práctico, lleno de ejemplos reales.',
          createdAt: '2024-05-10',
        },
      ],

      showInCarousel: true,
      isFeatured: true,
      isOffer: false,
      isNew: true,
      isActive: true,

      priceCLP: 89990,
      price: 89990,
      priceLabel: '$89.990',
    },

    {
      id: 'curso-piano',
      slug: 'curso-piano',
      title: 'Curso de piano',
      tutorId: 'sofia-arias',
      tutorName: 'Sofía Arias',

      difficulty: 'Intermedio',
      level: 'Intermedio',

      duration: '16 h · 8 clases',
      durationHours: 16,
      totalLessons: 8,
      lessonsCount: 8,

      shortDescription: 'Domina riffs, power chords y solos básicos de rock.',
      description:
        'En este curso trabajarás repertorio real de rock, técnica de púa, palm mute, power chords y construcción de solos sencillos sobre backing tracks.',
      imageUrl: '/assets/img/course/curso-teclado.jpg',

      rating: 4.8,
      ratingCount: 32,

      modalities: ['Presencial', 'Online'],

      stages: [
        'Fundamentos de palm mute',
        'Riffs clásicos',
        'Power chords y progresiones',
        'Introducción a solos',
      ],
      learnOutcomes: [
        'Tocar riffs con buen timing.',
        'Entender progresiones de rock.',
        'Improvisar solos sencillos.',
      ],

      reviews: [
        {
          author: 'Estudiante 1',
          rating: 5,
          comment: 'Curso muy práctico, lleno de ejemplos reales.',
          createdAt: '2024-05-10',
        },
      ],

      showInCarousel: true,
      isFeatured: true,
      isOffer: false,
      isNew: true,
      isActive: true,

      priceCLP: 89990,
      price: 89990,
      priceLabel: '$89.990',
    },

    {
      id: 'curso-guitarra',
      slug: 'curso-guitarra',
      title: 'Curso de guitarra',
      tutorId: 'felipe-contreras',
      tutorName: 'Felipe Contreras',

      difficulty: 'Intermedio',
      level: 'Intermedio',

      duration: '16 h · 8 clases',
      durationHours: 16,
      totalLessons: 8,
      lessonsCount: 8,

      shortDescription: 'Domina riffs, power chords y solos básicos de rock.',
      description:
        'En este curso trabajarás repertorio real de rock, técnica de púa, palm mute, power chords y construcción de solos sencillos sobre backing tracks.',
      imageUrl: '/assets/img/course/curso-guitarra.jpg',

      rating: 4.8,
      ratingCount: 32,

      modalities: ['Presencial', 'Online'],

      stages: [
        'Fundamentos de palm mute',
        'Riffs clásicos',
        'Power chords y progresiones',
        'Introducción a solos',
      ],
      learnOutcomes: [
        'Tocar riffs con buen timing.',
        'Entender progresiones de rock.',
        'Improvisar solos sencillos.',
      ],

      reviews: [
        {
          author: 'Estudiante 1',
          rating: 5,
          comment: 'Curso muy práctico, lleno de ejemplos reales.',
          createdAt: '2024-05-10',
        },
      ],

      showInCarousel: true,
      isFeatured: true,
      isOffer: false,
      isNew: true,
      isActive: true,

      priceCLP: 89990,
      price: 89990,
      priceLabel: '$89.990',
    },

    {
      id: 'curso-guitarra-electrica',
      slug: 'curso-guitarra-electrica',
      title: 'Curso de guitarra electrica',
      tutorId: 'claudio-san-martin',
      tutorName: 'Claudio San Martín',

      difficulty: 'Intermedio',
      level: 'Intermedio',

      duration: '16 h · 8 clases',
      durationHours: 16,
      totalLessons: 8,
      lessonsCount: 8,

      shortDescription: 'Domina riffs, power chords y solos básicos de rock.',
      description:
        'En este curso trabajarás repertorio real de rock, técnica de púa, palm mute, power chords y construcción de solos sencillos sobre backing tracks.',
      imageUrl: '/assets/img/course/curso-guitarra-e2.jpg',

      rating: 4.8,
      ratingCount: 32,

      modalities: ['Presencial', 'Online'],

      stages: [
        'Fundamentos de palm mute',
        'Riffs clásicos',
        'Power chords y progresiones',
        'Introducción a solos',
      ],
      learnOutcomes: [
        'Tocar riffs con buen timing.',
        'Entender progresiones de rock.',
        'Improvisar solos sencillos.',
      ],

      reviews: [
        {
          author: 'Estudiante 1',
          rating: 5,
          comment: 'Curso muy práctico, lleno de ejemplos reales.',
          createdAt: '2024-05-10',
        },
      ],

      showInCarousel: true,
      isFeatured: true,
      isOffer: false,
      isNew: true,
      isActive: true,

      priceCLP: 89990,
      price: 89990,
      priceLabel: '$89.990',
    },

    {
      id: 'curso-guitarra-clasica',
      slug: 'curso-guitarra-clasica',
      title: 'Curso de guitarra clasica',
      tutorId: 'valentina-zuniga',
      tutorName: 'Valentina Zúñiga',

      difficulty: 'Intermedio',
      level: 'Intermedio',

      duration: '16 h · 8 clases',
      durationHours: 16,
      totalLessons: 8,
      lessonsCount: 8,

      shortDescription: 'Domina riffs, power chords y solos básicos de rock.',
      description:
        'En este curso trabajarás repertorio real de rock, técnica de púa, palm mute, power chords y construcción de solos sencillos sobre backing tracks.',
      imageUrl: '/assets/img/course/curso-guitarra.jpg',

      rating: 4.8,
      ratingCount: 32,

      modalities: ['Presencial', 'Online'],

      stages: [
        'Fundamentos de palm mute',
        'Riffs clásicos',
        'Power chords y progresiones',
        'Introducción a solos',
      ],
      learnOutcomes: [
        'Tocar riffs con buen timing.',
        'Entender progresiones de rock.',
        'Improvisar solos sencillos.',
      ],

      reviews: [
        {
          author: 'Estudiante 1',
          rating: 5,
          comment: 'Curso muy práctico, lleno de ejemplos reales.',
          createdAt: '2024-05-10',
        },
      ],

      showInCarousel: true,
      isFeatured: true,
      isOffer: false,
      isNew: true,
      isActive: true,

      priceCLP: 89990,
      price: 89990,
      priceLabel: '$89.990',
    },

    // aquí puedes seguir sumando cursos con el mismo patrón
  ];

  // ============================================================
  // 2) MÉTODOS PÚBLICOS (LECTURA BÁSICA)
  // ============================================================

  // Devuelve todos los cursos tal cual están en memoria.
  // Se usa para listados generales o para el Admin.
  getAll(): Course[] {
    return this.courses;
  }

  // Nombre que usa curso-detail.ts para resolver la ruta /cursos/:slug
  getBySlug(slug: string): Course | undefined {
    return this.courses.find((c) => c.slug === slug);
  }

  // Alias utilizado por otros componentes (por ejemplo el breadcrumb).
  getCourseBySlug(slug: string): Course | undefined {
    return this.getBySlug(slug);
  }

  // Devuelve todos los cursos de un tutor, con la opción de excluir uno
  // (por ejemplo, para no repetir el curso actual en "Más cursos de este tutor").
  getByTutorId(tutorId: string, exceptId?: string): Course[] {
    return this.courses.filter(
      (c) => c.tutorId === tutorId && c.id !== exceptId,
    );
  }

  // Alias del anterior, por si en algún punto lo llamas con otro nombre.
  getCoursesByTutor(tutorId: string, exceptId?: string): Course[] {
    return this.getByTutorId(tutorId, exceptId);
  }

  // ============================================================
  // 3) ARMADO DE DATA PARA EL CARRUSEL
  // ============================================================
  // Mapea cursos destacados a CarouselItem para reutilizar el componente de carrusel del home.
  getFeaturedCoursesForCarousel(limit = 8): CarouselItem[] {
    return this.courses
      .filter((c) => c.isFeatured)
      .slice(0, limit)
      .map<CarouselItem>((c) => ({
        id: c.id,
        type: 'course',
        title: c.title,
        subtitle: c.tutorName,
        description: c.shortDescription,
        imageUrl: c.imageUrl || 'assets/img/courses/default.jpg',
        price: c.priceCLP,
        rating: c.rating,
        dateLabel: c.duration, // aquí reutilizo la duración como texto que se muestra en el card
        ctaLabel: 'Ver curso',
        ctaLink: `/cursos/${c.slug}`,
      }));
  }

  // ============================================================
  // 4) ADMIN (CRUD LOCAL)
  // ============================================================
  // Agrega un curso nuevo al arreglo (modo local).
  addCourse(course: Course): void {
    this.courses.push(course);
  }

  // Actualiza un curso existente buscando por id.
  updateCourse(updated: Course): void {
    const index = this.courses.findIndex((c) => c.id === updated.id);
    if (index !== -1) {
      this.courses[index] = { ...updated };
    }
  }

  // Elimina un curso por id del arreglo local.
  deleteCourse(id: string): void {
    this.courses = this.courses.filter((c) => c.id !== id);
  }
}
