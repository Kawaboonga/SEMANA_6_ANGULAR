import { FadeUp } from './fade-up';

describe('FadeUp', () => {
  it('should create an instance', () => {
    const directive = new FadeUp();
    expect(directive).toBeTruthy();
  });
});
