// src/app/shared/forms/tutor-form/tutor-form.ts

import {
  Component,
  EventEmitter,
  Input,
  Output,
  OnInit,
  OnChanges,
  SimpleChanges,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';

import { Tutor } from '@core/models/tutor';

interface AvailabilityOption {
  id: string;
  label: string;
}

@Component({
  selector: 'app-tutor-form',
  standalone: true,
  templateUrl: './tutor-form.html',
  imports: [CommonModule, ReactiveFormsModule],
})
export class TutorFormComponent implements OnInit, OnChanges {
  @Input() value: Tutor | null = null;
  @Output() save = new EventEmitter<Tutor>();
  @Output() cancel = new EventEmitter<void>();

  form!: FormGroup;

  // ============================================================
  // 1. LISTAS PREDEFINIDAS
  // ============================================================

  // Ubicación: comunas de la RM predefinidas
  communes: string[] = [
    'Santiago Centro',
    'Huechuraba',
    'Providencia',
    'Ñuñoa',
    'Las Condes',
    'La Reina',
    'Recoleta',
    'Independencia',
    'Macul',
    'Peñalolén',
    'Maipú',
    'La Florida',
    'Puente Alto',
    'San Miguel',
  ];

  // Instrumentos (valor + etiqueta legible)
  instrumentOptions: { value: string; label: string }[] = [
    { value: 'guitarra-electrica', label: 'Guitarra eléctrica' },
    { value: 'guitarra-acustica', label: 'Guitarra acústica' },
    { value: 'bajo', label: 'Bajo eléctrico' },
    { value: 'teclado', label: 'Teclado / Piano' },
    { value: 'bateria', label: 'Batería' },
    { value: 'canto', label: 'Canto' },
    { value: 'ukelele', label: 'Ukelele' },
  ];

  // Estilos
  styleOptions: string[] = [
    'rock',
    'metal',
    'pop',
    'blues',
    'jazz',
    'funk',
    'indie',
    'latino',
  ];

  // Modalidades
  modalityOptions: string[] = ['presencial', 'online'];

  // Rating predefinidos
  ratingOptions: number[] = [5, 4.8, 4.5, 4.2, 4, 3.8, 3.5];

  // Cantidad de reseñas predefinidas
  ratingCountOptions: number[] = [0, 3, 5, 10, 20, 30, 50, 100];

  // Idiomas
  languageOptions: string[] = ['Español', 'Inglés', 'Portugués'];

  // Disponibilidad semanal → se selecciona por ID
  availabilityOptions: AvailabilityOption[] = [
    {
      id: 'lun-vie-tarde',
      label: 'Lunes a viernes · 19:00–21:00',
    },
    {
      id: 'sab-manana',
      label: 'Sábados · 10:00–13:00',
    },
    {
      id: 'lun-mie-19',
      label: 'Lunes y miércoles · 19:00',
    },
  ];

  constructor(private fb: FormBuilder) {}

  // ============================================================
  // 2. CICLO DE VIDA
  // ============================================================

  ngOnInit(): void {
    this.buildForm();

    if (this.value) {
      this.patchForm(this.value);
    }
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['value'] && this.form) {
      this.patchForm(this.value);
    }
  }

  // ============================================================
  // 3. CREACIÓN Y CARGA DEL FORM
  // ============================================================

  private buildForm(): void {
    this.form = this.fb.group({
      name: ['', Validators.required],

      commune: ['', Validators.required],
      city: [''],

      avatarUrl: [''],

      instruments: this.fb.control<string[]>([], {
        validators: Validators.required,
        nonNullable: true,
      }),
      styles: this.fb.control<string[]>([], {
        validators: Validators.required,
        nonNullable: true,
      }),
      modalities: this.fb.control<string[]>([], {
        validators: Validators.required,
        nonNullable: true,
      }),

      hourlyRate: ['', Validators.required],

      rating: [4.8],
      ratingCount: [10],

      shortDescription: ['', Validators.required],
      fullDescription: [''],

      experience: [''],
      education: [''],

      languages: this.fb.control<string[]>(['Español'], {
        validators: Validators.required,
        nonNullable: true,
      }),

      // IDs de disponibilidad elegidos en el <select multiple>
      availabilityIds: this.fb.control<string[]>([], {
        nonNullable: true,
      }),
    });
  }

  private patchForm(tutor: Tutor | null): void {
    if (!tutor) return;

    const t: any = tutor;

    this.form.patchValue({
      name: tutor.name ?? '',
      commune: t.commune ?? t.city ?? '',
      city: t.city ?? '',
      avatarUrl: tutor.avatarUrl ?? '',

      instruments: tutor.instruments ?? [],
      styles: tutor.styles ?? [],
      modalities: tutor.modalities ?? [],

      hourlyRate: t.hourlyRate ?? '',

      rating: tutor.rating ?? 4.8,
      ratingCount: t.ratingCount ?? 0,

      shortDescription: t.shortDescription ?? '',
      fullDescription: t.fullDescription ?? '',

      experience: t.experience ?? '',
      education: t.education ?? '',

      languages: tutor.languages ?? ['Español'],

      // Si ya tienes weeklyAvailability podrías inferir availabilityIds;
      // para simplificar los dejamos vacíos y el admin los setea.
      availabilityIds: [],
    });
  }

  // ============================================================
  // 4. HELPERS DE VALIDACIÓN
  // ============================================================

  hasError(controlName: string, error: string): boolean {
    const control = this.form.get(controlName);
    return !!(control && control.touched && control.hasError(error));
  }

  // ============================================================
  // 5. MAPEOS / UTILIDADES
  // ============================================================

  private mapAvailabilityFromIds(ids: string[]): any[] {
    const result: any[] = [];

    for (const id of ids) {
      switch (id) {
        case 'lun-vie-tarde':
          result.push(
            { day: 'Lunes', times: ['19:00', '20:00', '21:00'] },
            { day: 'Martes', times: ['19:00', '20:00', '21:00'] },
            { day: 'Miércoles', times: ['19:00', '20:00', '21:00'] },
            { day: 'Jueves', times: ['19:00', '20:00', '21:00'] },
            { day: 'Viernes', times: ['19:00', '20:00', '21:00'] },
          );
          break;

        case 'sab-manana':
          result.push({
            day: 'Sábado',
            times: ['10:00', '11:00', '12:00', '13:00'],
          });
          break;

        case 'lun-mie-19':
          result.push(
            { day: 'Lunes', times: ['19:00'] },
            { day: 'Miércoles', times: ['19:00'] },
          );
          break;

        default:
          // si llega un id no conocido, lo ignoramos
          break;
      }
    }

    return result;
  }

  private slugify(text: string): string {
    return text
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-+|-+$/g, '');
  }

  // ============================================================
  // 6. SUBMIT / CANCEL
  // ============================================================

  onMultiSelectChange(controlName: string, event: Event): void {
  const select = event.target as HTMLSelectElement;
  const selectedValues = Array.from(select.selectedOptions).map(
    option => option.value
  );

  this.form.get(controlName)?.setValue(selectedValues);
  this.form.get(controlName)?.markAsDirty();
  this.form.get(controlName)?.markAsTouched();
}



  onSubmit(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }

    const raw = this.form.getRawValue();

    const weeklyAvailability = this.mapAvailabilityFromIds(
      raw.availabilityIds ?? [],
    );

    const payload: Partial<Tutor> = {
      ...(this.value ?? {}),
      id: this.value?.id ?? this.slugify(raw.name ?? ''),
      name: raw.name?.trim(),
      commune: raw.commune,
      city: raw.city,
      avatarUrl: raw.avatarUrl?.trim(),

      instruments: raw.instruments ?? [],
      styles: raw.styles ?? [],
      modalities: raw.modalities ?? [],

      hourlyRate: Number(raw.hourlyRate),

      rating: raw.rating ?? 0,
      ratingCount: raw.ratingCount ?? 0,

      shortDescription: raw.shortDescription,
      fullDescription: raw.fullDescription,

      experience: raw.experience,
      education: raw.education,

      languages: raw.languages ?? [],

      weeklyAvailability,
    };

    this.save.emit(payload as Tutor);
  }

  onCancel(): void {
    this.cancel.emit();
  }
}
