// src/app/features/auth/login/login.component.spec.ts

import { TestBed, fakeAsync, tick } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';

import { LoginComponent } from './login';
import { AuthService } from '@core/services/auth.service';
import { CommonModule } from '@angular/common';
import { RouterTestingModule } from '@angular/router/testing';

// Mock sencillo para AuthService
const authServiceMock = {
  login: jasmine.createSpy('login'),
};

// Mock sencillo para Router
const routerMock = {
  navigate: jasmine.createSpy('navigate'),
};

describe('LoginComponent', () => {
  let component: LoginComponent;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        CommonModule,
        ReactiveFormsModule,
        RouterTestingModule,
        LoginComponent, // standalone
      ],
      providers: [
        { provide: AuthService, useValue: authServiceMock },
        { provide: Router, useValue: routerMock },
      ],
    });

    const fixture = TestBed.createComponent(LoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();

    // Reseteamos los spies antes de cada test
    authServiceMock.login.calls.reset();
    routerMock.navigate.calls.reset();
  });

  it('no debería llamar a auth.login si el formulario es inválido', () => {
    // Arrange
    // De forma predeterminada el formulario está vacío → inválido
    expect(component.form.invalid).toBeTrue();

    // Act
    component.onSubmit();

    // Assert
    expect(authServiceMock.login).not.toHaveBeenCalled();
    expect(component.loading).toBeFalse();
  });

  it('debería llamar a auth.login y navegar a /mi-cuenta con credenciales correctas', fakeAsync(() => {
    // Arrange
    authServiceMock.login.and.returnValue({
      success: true,
      message: 'Inicio de sesión exitoso',
    });

    component.form.setValue({
      email: 'admin@soundseeker.cl',
      password: 'Admin123',
    });

    // Act
    component.onSubmit();

    // Assert inmediato (antes del setTimeout)
    expect(authServiceMock.login).toHaveBeenCalledWith({
      email: 'admin@soundseeker.cl',
      password: 'Admin123',
    });

    expect(component.successMessage).toContain('exitoso');

    // Avanzamos el tiempo simulado para que se ejecute el setTimeout(800)
    tick(800);

    expect(routerMock.navigate).toHaveBeenCalledWith(['/mi-cuenta']);
    expect(component.loading).toBeFalse();
  }));
});
