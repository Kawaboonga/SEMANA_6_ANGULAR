import type { Tutor as CoreTutor } from '@core/models/tutor';
// Si en alguna parte quedara algo viejo, que importe AdminTutor en vez de Tutor.
export type AdminTutor = CoreTutor;
