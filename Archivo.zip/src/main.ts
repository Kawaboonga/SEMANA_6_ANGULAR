import { bootstrapApplication } from '@angular/platform-browser';
import { App } from './app/app';
import { appConfig } from './app/app.config';


bootstrapApplication(App, appConfig).then(() => {
  if (typeof window !== 'undefined' && typeof document !== 'undefined') {
    document.body.classList.add('is-loaded');
  }
});

/*bootstrapApplication(App, appConfig)
  .then(() => {
    // cuando Angular ya cargo, activa la transición del body definida en el CSS global.
    document.body.classList.add('is-loaded');
  })
  .catch((err) => console.error(err));*/