declare module 'bootstrap/js/dist/collapse';
declare module 'bootstrap/js/dist/dropdown';
declare module 'bootstrap/js/dist/offcanvas';
declare module 'bootstrap';