export interface User {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  password: string;
  dateOfBirth: string;
  shippingAddress?: string;
  role: 'admin' | 'instructor' | 'user';
  isActive: boolean;
}
