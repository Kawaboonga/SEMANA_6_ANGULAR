import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

// Modelo simple para productos que vienen desde la API externa.
// Este modelo se usa en páginas de listado, detalle y cards rápidas.
export interface Producto {
  id: number;                              // ID único del producto (lo entrega el backend)
  nombre: string;                          // Nombre visible del producto
  tipo: 'guitarra' | 'bajo' | 'amplificador' | 'pedal'; 
  // Tipo principal: sirve para filtros básicos (categorías)

  precio: number;                          // Precio final
  imagen: string;                          // URL de la imagen del producto
  comuna: string;                          // Dónde está ubicado (útil para filtros por distancia)
}

@Injectable({ providedIn: 'root' })
export class ProductosService {
  // Base URL para las solicitudes HTTP.
  // Mejor centralizado aquí para poder cambiarlo fácilmente según ambiente.
  private baseUrl = '/api/productos';

  constructor(private http: HttpClient) {}

  // Obtiene TODOS los productos desde la API.
  // Se usa en listados y páginas que necesitan el catálogo completo.
  getProductos(): Observable<Producto[]> {
    return this.http.get<Producto[]>(this.baseUrl);
  }

  // Obtiene un solo producto por ID.
  // Perfecto para la página de detalle /producto/:id
  getProducto(id: number): Observable<Producto> {
    return this.http.get<Producto>(`${this.baseUrl}/${id}`);
  }
}
